extends Area2D
class_name PowerUpPickup

@export var powerup_data: PowerUpData

@onready var sprite: Sprite2D = $Sprite2D
@onready var beam: LootBeam = $PowerupBeam
@onready var pickup_sound: AudioStreamPlayer2D = $PickupSound

func _ready() -> void:
	if powerup_data == null:
		push_warning("PowerUpPickup has no PowerUpData assigned.")
		return
	if powerup_data.icon:
		sprite.texture = powerup_data.icon
	_apply_rarity_visuals()
	pickup_sound.play()
	await pickup_sound.finished

func _on_body_entered(body: Node) -> void:
	if not body.has_node("StatsComponent"):
		return
	var stats = body.get_node("StatsComponent")
	stats.apply_powerup(powerup_data)
	sprite.visible = false
	beam.visible = false
	set_deferred("monitoring", false)
	queue_free()

func _apply_rarity_visuals() -> void:
	var loot_rarity: LootBeam.Rarity

	match powerup_data.rarity:
		PowerUpData.Rarity.COMMON:
			loot_rarity = LootBeam.Rarity.COMMON
		PowerUpData.Rarity.RARE:
			loot_rarity = LootBeam.Rarity.RARE
		PowerUpData.Rarity.EPIC:
			loot_rarity = LootBeam.Rarity.EPIC
		PowerUpData.Rarity.LEGENDARY:
			loot_rarity = LootBeam.Rarity.LEGENDARY

	beam.set_rarity(loot_rarity)
	beam.set_item_name(powerup_data.display_name)
