class_name LootRarity

enum Tier {
	COMMON,
	MAGIC,
	RARE,
	EPIC,
	LEGENDARY,
	UNIQUE
}

static func get_color(tier: Tier) -> Color:
	match tier:
		Tier.COMMON:
			return Color(0.85, 0.85, 0.85)
		Tier.MAGIC:
			return Color(0.1, 0.45, 1.0)
		Tier.RARE:
			return Color(1.0, 0.85, 0.05)
		Tier.EPIC:
			return Color(0.65, 0.15, 1.0)
		Tier.LEGENDARY:
			return Color(1.0, 0.35, 0.0)
		Tier.UNIQUE:
			return Color(1.0, 0.05, 0.05)
		_:
			return Color.WHITE
