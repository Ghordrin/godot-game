extends Area2D
class_name PowerUpPickup

@export var powerup_data: PowerUpData

@onready var sprite: Sprite2D = $Sprite2D
@onready var label: Label = $Label
@onready var beam: LootBeam = $LootBeam


func _ready() -> void:
	setup_visuals()


func setup_visuals() -> void:
	label.visible = true
	label.z_index = 100

	if powerup_data == null:
		push_warning("PowerUpPickup has no powerup_data assigned.")
		label.text = "NO POWERUP DATA"
		label.modulate = Color.RED
		return

	print("Powerup name: ", powerup_data.display_name)
	print("Powerup rarity: ", powerup_data.rarity)

	var rarity_color := get_rarity_color(powerup_data.rarity)

	label.text = powerup_data.display_name
	label.modulate = rarity_color

	if powerup_data.icon != null:
		sprite.texture = powerup_data.icon

	beam.set_rarity_color(rarity_color)


func _on_body_entered(body: Node) -> void:
	if not body.has_node("StatsComponent"):
		return

	var stats = body.get_node("StatsComponent")
	stats.apply_powerup(powerup_data)

	queue_free()


func get_rarity_color(rarity: PowerUpData.Rarity) -> Color:
	match rarity:
		PowerUpData.Rarity.COMMON:
			return Color.WHITE

		PowerUpData.Rarity.RARE:
			return Color.DODGER_BLUE

		PowerUpData.Rarity.EPIC:
			return Color.MEDIUM_PURPLE

		PowerUpData.Rarity.LEGENDARY:
			return Color.GOLD

	return Color.WHITE
