extends CharacterBody2D

@export var move_speed: float = 75.0
@export var stop_distance: float = 28.0
@export var attack_distance: float = 22.0

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var health_component: HealthComponent = $HealthComponent
@onready var detection_area: Area2D = $DetectionArea
@onready var collision: CollisionShape2D = $CollisionShape2D

@export var loot_table: LootTable
@export var loot_item_scene: PackedScene
@export var gold_pickup_scene: PackedScene
@export var min_gold_drop := 1
@export var max_gold_drop := 5

var target: Node2D = null
var last_direction: Vector2 = Vector2.DOWN


func _ready() -> void:
	detection_area.body_entered.connect(_on_detection_area_body_entered)
	detection_area.body_exited.connect(_on_detection_area_body_exited)
	health_component.died.connect(_on_died)


func _physics_process(_delta: float) -> void:
	if health_component.is_dead:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	if is_instance_valid(target):
		follow_target()
	else:
		target = null
		velocity = Vector2.ZERO
		play_idle_animation()

	move_and_slide()

func drop_gold() -> void:
	if gold_pickup_scene == null:
		push_warning("No gold_pickup_scene assigned on enemy.")
		return

	var gold_pickup := gold_pickup_scene.instantiate() as GoldPickup

	if gold_pickup == null:
		push_warning("gold_pickup_scene is not a GoldPickup.")
		return

	gold_pickup.gold_amount = randi_range(min_gold_drop, max_gold_drop)
	gold_pickup.global_position = global_position + Vector2(randf_range(-12, 12), randf_range(-12, 12))

	get_tree().current_scene.add_child(gold_pickup)

	print("Dropped gold:", gold_pickup.gold_amount)
	
func drop_loot() -> void:
	print("drop_loot called")

	if loot_table == null:
		print("No loot_table assigned")
		return

	if loot_item_scene == null:
		print("No loot_item_scene assigned")
		return

	var drops: Array[PowerUpData] = loot_table.roll_drops()

	print("Drops rolled: ", drops.size())

	for i in drops.size():
		if drops[i] == null:
			print("Drop was null at index ", i)
			continue

		print("Trying to spawn: ", drops[i].display_name)

		var powerup_pickup := loot_item_scene.instantiate() as PowerUpPickup

		if powerup_pickup == null:
			print("Scene is not a PowerUpPickup. Check script/class_name.")
			return

		powerup_pickup.powerup_data = drops[i]
		powerup_pickup.global_position = global_position + Vector2(i * 18, 0)

		get_tree().current_scene.add_child(powerup_pickup)

		print("Dropped powerup: ", drops[i].display_name)
func follow_target() -> void:
	var direction: Vector2 = global_position.direction_to(target.global_position)
	var distance: float = global_position.distance_to(target.global_position)

	last_direction = direction

	if distance > stop_distance:
		velocity = direction * move_speed
		play_walk_animation(direction)
	else:
		velocity = Vector2.ZERO
		play_idle_animation()


func _on_detection_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		target = body
		print("Goblin alerted.")


func _on_detection_area_body_exited(body: Node2D) -> void:
	if body == target:
		target = null
		velocity = Vector2.ZERO
		print("Goblin lost target.")


func _on_died() -> void:
	target = null
	velocity = Vector2.ZERO

	collision.set_deferred("disabled", true)
	detection_area.monitoring = false
	detection_area.monitorable = false
	drop_gold()
	drop_loot()
	play_death_animation()


func play_walk_animation(direction: Vector2) -> void:
	if animated_sprite.sprite_frames == null:
		return

	if abs(direction.x) > abs(direction.y):
		if direction.x > 0:
			_play_if_exists("walk_right")
		else:
			_play_if_exists("walk_left")
	else:
		if direction.y > 0:
			_play_if_exists("walk_down")
		else:
			_play_if_exists("walk_up")


func play_idle_animation() -> void:
	if animated_sprite.sprite_frames == null:
		return

	_play_if_exists("idle")


func play_death_animation() -> void:
	if animated_sprite.sprite_frames != null and animated_sprite.sprite_frames.has_animation("death"):
		animated_sprite.play("death")
	else:
		hide()


func _play_if_exists(animation_name: String) -> void:
	if animated_sprite.sprite_frames == null:
		return

	if animated_sprite.sprite_frames.has_animation(animation_name):
		if animated_sprite.animation != animation_name:
			animated_sprite.play(animation_name)
