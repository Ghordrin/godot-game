extends Resource
class_name LootTable

@export var guaranteed_drops: Array[PowerUpData] = []
@export var random_drops: Array[PowerUpData] = []
@export var rare_drops: Array[PowerUpData] = []

@export_range(0.0, 1.0) var random_drop_chance: float = 0.6
@export_range(0.0, 1.0) var rare_drop_chance: float = 0.08


func roll_drops() -> Array[PowerUpData]:
	var drops: Array[PowerUpData] = []

	for powerup: PowerUpData in guaranteed_drops:
		if powerup != null:
			drops.append(powerup)

	if random_drops.size() > 0 and randf() <= random_drop_chance:
		var powerup: PowerUpData = random_drops.pick_random() as PowerUpData

		if powerup != null:
			drops.append(powerup)

	if rare_drops.size() > 0 and randf() <= rare_drop_chance:
		var rare_powerup: PowerUpData = rare_drops.pick_random() as PowerUpData

		if rare_powerup != null:
			drops.append(rare_powerup)

	return drops
