extends CharacterBody2D

@export var projectile_scene: PackedScene

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var health_component: HealthComponent = $HealthComponent
@onready var stats = $StatsComponent

var last_move_direction: Vector2 = Vector2.DOWN
var facing_direction: Vector2 = Vector2.DOWN
var can_move: bool = true


func _ready() -> void:
	health_component.died.connect(_on_died)


func _physics_process(_delta: float) -> void:
	if not can_move:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	var input_vector := Input.get_vector(
		"move_left",
		"move_right",
		"move_up",
		"move_down"
	)

	if Input.is_action_just_pressed("cast_projectile"):
		attack_towards_mouse()

	if Input.is_action_just_pressed("debug_dmg"):
		health_component.take_damage(10)

	if input_vector != Vector2.ZERO:
		velocity = input_vector.normalized() * stats.move_speed
		last_move_direction = input_vector
		facing_direction = input_vector
		play_walk_animation(input_vector)
	else:
		velocity = Vector2.ZERO
		play_idle_animation()

	move_and_slide()


func attack_towards_mouse() -> void:
	var mouse_direction := get_mouse_attack_direction()

	facing_direction = screen_direction_to_cardinal(mouse_direction)

	play_cast_animation()
	cast_projectile(mouse_direction)


func get_mouse_attack_direction() -> Vector2:
	var mouse_direction: Vector2 = global_position.direction_to(get_global_mouse_position())

	if mouse_direction == Vector2.ZERO:
		return facing_direction

	return mouse_direction.normalized()


func screen_direction_to_cardinal(direction: Vector2) -> Vector2:
	if abs(direction.x) > abs(direction.y):
		if direction.x > 0:
			return Vector2.RIGHT
		else:
			return Vector2.LEFT
	else:
		if direction.y > 0:
			return Vector2.DOWN
		else:
			return Vector2.UP


func cast_projectile(shoot_direction: Vector2) -> void:
	if projectile_scene == null:
		push_warning("No projectile scene assigned.")
		return

	var projectile := projectile_scene.instantiate() as Projectile
	get_tree().current_scene.add_child(projectile)

	projectile.global_position = global_position
	projectile.setup(shoot_direction, stats.damage)


func _on_died() -> void:
	can_move = false
	velocity = Vector2.ZERO
	print("Player died.")

	await get_tree().create_timer(1.5).timeout
	get_tree().reload_current_scene()


func play_cast_animation() -> void:
	play_directional_animation("attack", facing_direction)


func play_walk_animation(direction: Vector2) -> void:
	play_directional_animation("walk", direction)


func play_idle_animation() -> void:
	play_directional_animation("idle", facing_direction)


func play_directional_animation(prefix: String, direction: Vector2) -> void:
	if abs(direction.x) > abs(direction.y):
		if direction.x > 0:
			_play_if_exists(prefix + "_right")
		else:
			_play_if_exists(prefix + "_left")
	else:
		if direction.y > 0:
			_play_if_exists(prefix + "_down")
		else:
			_play_if_exists(prefix + "_up")


func _play_if_exists(animation_name: String) -> void:
	if animated_sprite.sprite_frames == null:
		return

	if animated_sprite.sprite_frames.has_animation(animation_name):
		if animated_sprite.animation != animation_name:
			animated_sprite.play(animation_name)
