extends Area2D
class_name GoldPickup

@export var gold_amount := 1

@onready var label: Label = $Label


func _ready() -> void:
	label.text = str(gold_amount) + " gold"


func _on_body_entered(body: Node) -> void:
	if not body.has_node("StatsComponent"):
		return

	var stats = body.get_node("StatsComponent")
	stats.add_gold(gold_amount)

	queue_free()
